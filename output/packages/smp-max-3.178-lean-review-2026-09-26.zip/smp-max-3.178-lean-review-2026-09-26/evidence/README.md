# Formal proof evidence and the reproduction fix

The original formal verification was completed on 24 September 2026:
56 modules built, 112 statements audited, all 45 target-dependency modules
replayed independently, and nine pinned external revisions checked.
The proof build reused the pinned Mathlib cache; the download step was not
retested. Those formal inputs and logs remain byte-identical, as recorded
in `revision-identity.json`. No repeated full formal build is claimed here.

The seven-page PDF and its LaTeX source are unchanged from the inspected
25 September edition. `pdf-review.json` and `latex-build.log` retain that
presentation evidence.

The 26 September README directs rebuilt output to `build/PROOF.pdf` so
that the sealed root PDF remains intact. `rebuild-validation.json` records
successful identity checks before and after executing this corrected build.
Generated build and verification directories are excluded from the archive.
