# Lean source map

All 56 theorem modules preserve their original checked bytes. The main theorem uses 45 local modules.

## Read the argument in this order

1. Definitions, stable-pair separation, and actual conditional supports.
2. Finite revelation entropy and uniform permutation gap estimates.
3. Refined finite logarithm certificate at cutoff 512.
4. Successor/predecessor propagation and exact longer-event rows.
5. Simultaneous-cap losses, collision cases, and exception charging.
6. `JointEntropyUpperBound.lean` and the exact statement in `Check3178.lean`.

## Complete inventory

| Module | Role in the target | Description |
|---|---|---|
| [Barriers](lean/SmpMax/General/Barriers.lean) | Target dependency | Revealed stable pairs are barriers |
| [BidirectionalEntropyUpperBound](lean/SmpMax/General/BidirectionalEntropyUpperBound.lean) | Preserved earlier development | The unconditional general 3.2 upper bound |
| [BidirectionalGapSaving](lean/SmpMax/General/BidirectionalGapSaving.lean) | Target dependency | Combining both directional gap losses |
| [BidirectionalLogCertificate](lean/SmpMax/General/BidirectionalLogCertificate.lean) | Target dependency | Arithmetic for two directional savings and a base of 3.2 |
| [BidirectionalPropagation](lean/SmpMax/General/BidirectionalPropagation.lean) | Target dependency | Changes toward better stable partners also propagate |
| [Definitions](lean/SmpMax/General/Definitions.lean) | Target dependency | Complete strict stable marriage at arbitrary order |
| [EntropyUpperBound](lean/SmpMax/General/EntropyUpperBound.lean) | Preserved earlier development | The general 3.332 exponential upper bound |
| [ExtendedRevelation](lean/SmpMax/General/ExtendedRevelation.lean) | Target dependency | Revelation with ranks in a larger finite set |
| [FiniteAverageAlgebra](lean/SmpMax/General/FiniteAverageAlgebra.lean) | Target dependency | Formal proof component |
| [FiniteProbability](lean/SmpMax/General/FiniteProbability.lean) | Target dependency | Uniform probability on a nonempty finite space |
| [FiniteRevelation](lean/SmpMax/General/FiniteRevelation.lean) | Target dependency | Finite counting by successive coordinate revelation |
| [GapSides](lean/SmpMax/General/GapSides.lean) | Target dependency | Formal proof component |
| [GapTail](lean/SmpMax/General/GapTail.lean) | Target dependency | A uniform tail bound for the revelation gap |
| [JointCharging](lean/SmpMax/General/JointCharging.lean) | Target dependency | Charging exceptions while retaining a joint directional saving |
| [JointDirectionalSaving](lean/SmpMax/General/JointDirectionalSaving.lean) | Target dependency | Stronger noncycle savings and cross-direction collision margins |
| [JointEntropyUpperBound](lean/SmpMax/General/JointEntropyUpperBound.lean) | Target dependency | The unconditional general 3.178 upper bound |
| [JointGapGeometry](lean/SmpMax/General/JointGapGeometry.lean) | Target dependency | A joint saving on the actual padded partner gap |
| [JointGapSaving](lean/SmpMax/General/JointGapSaving.lean) | Target dependency | The positive remainder when both directional caps shrink |
| [JointLogCertificate](lean/SmpMax/General/JointLogCertificate.lean) | Target dependency | Exact margins for the simultaneous-cap saving and the base 3.178 |
| [JointMatchingSaving](lean/SmpMax/General/JointMatchingSaving.lean) | Target dependency | Matching-level charging with the joint directional bonus |
| [LocalDirectionalSaving](lean/SmpMax/General/LocalDirectionalSaving.lean) | Preserved earlier development | Expected directional losses from local events |
| [LocalGapEvents](lean/SmpMax/General/LocalGapEvents.lean) | Preserved earlier development | Local events around a padded pivot |
| [LocalGapGeometry](lean/SmpMax/General/LocalGapGeometry.lean) | Preserved earlier development | Formal proof component |
| [LogCertificate](lean/SmpMax/General/LogCertificate.lean) | Preserved earlier development | Kernel-checked rational certificate at cutoff 512 |
| [LogCutoff](lean/SmpMax/General/LogCutoff.lean) | Target dependency | A finite cutoff bound uniform in the list length |
| [LogEnclosure](lean/SmpMax/General/LogEnclosure.lean) | Target dependency | Rational enclosures for the finite logarithmic constant |
| [LogTail](lean/SmpMax/General/LogTail.lean) | Target dependency | Finite logarithmic tail sums |
| [LongDirectionalSaving](lean/SmpMax/General/LongDirectionalSaving.lean) | Target dependency | Expected directional losses from local events |
| [LongEventRows](lean/SmpMax/General/LongEventRows.lean) | Target dependency | Exhaustive witness-coincidence rows for the longer events |
| [LongGapEvents](lean/SmpMax/General/LongGapEvents.lean) | Target dependency | Longer opposite-side events around a padded pivot |
| [LongGapGeometry](lean/SmpMax/General/LongGapGeometry.lean) | Target dependency | Formal proof component |
| [LongMatchingDirectionalSaving](lean/SmpMax/General/LongMatchingDirectionalSaving.lean) | Target dependency | Formal proof component |
| [LongPaddedOwners](lean/SmpMax/General/LongPaddedOwners.lean) | Target dependency | Forty-eight auxiliary owner labels, without adding matching coordinates |
| [LongPaddedSupport](lean/SmpMax/General/LongPaddedSupport.lean) | Target dependency | Formal proof component |
| [LongerEntropyUpperBound](lean/SmpMax/General/LongerEntropyUpperBound.lean) | Preserved earlier development | The unconditional general 3.18 upper bound |
| [LongerLogCertificate](lean/SmpMax/General/LongerLogCertificate.lean) | Target dependency | Exact certificates for a longer-event saving and the base 3.18 |
| [MatchingDirectionalSaving](lean/SmpMax/General/MatchingDirectionalSaving.lean) | Preserved earlier development | Formal proof component |
| [MatchingRevelation](lean/SmpMax/General/MatchingRevelation.lean) | Target dependency | The finite revelation inequality for stable matchings |
| [PaddedOwners](lean/SmpMax/General/PaddedOwners.lean) | Preserved earlier development | Six auxiliary owner labels, without adding matching coordinates |
| [PaddedSupport](lean/SmpMax/General/PaddedSupport.lean) | Preserved earlier development | Formal proof component |
| [PartnerFrame](lean/SmpMax/General/PartnerFrame.lean) | Target dependency | Formal proof component |
| [PartnerIntervals](lean/SmpMax/General/PartnerIntervals.lean) | Target dependency | Conditional support lies in a stable-partner interval |
| [PermutationCounting](lean/SmpMax/General/PermutationCounting.lean) | Target dependency | Exact counts of first and second positions in a random permutation |
| [PermutationRevelation](lean/SmpMax/General/PermutationRevelation.lean) | Target dependency | Averaging revelation costs over permutations of the fixed men |
| [RefinedEntropyUpperBound](lean/SmpMax/General/RefinedEntropyUpperBound.lean) | Preserved earlier development | The refined general 3.331974 upper bound |
| [RefinedLogBound](lean/SmpMax/General/RefinedLogBound.lean) | Target dependency | A sharper finite logarithmic remainder |
| [RefinedLogCertificate](lean/SmpMax/General/RefinedLogCertificate.lean) | Target dependency | Kernel-checked certificate for the base 3.331974 |
| [RelativeOrderProbability](lean/SmpMax/General/RelativeOrderProbability.lean) | Target dependency | Exact relative-order probabilities with up to two earlier labels |
| [RevelationGap](lean/SmpMax/General/RevelationGap.lean) | Target dependency | Nearest revealed barriers and finite windows |
| [Separation](lean/SmpMax/General/Separation.lean) | Target dependency | Stable-pair separation for arbitrary order |
| [ShortSideSaving](lean/SmpMax/General/ShortSideSaving.lean) | Target dependency | A uniform saving when at most one stable partner lies to the right |
| [StructuralLogCertificate](lean/SmpMax/General/StructuralLogCertificate.lean) | Target dependency | Exact arithmetic for the proposed structural bound |
| [SuccessorCharging](lean/SmpMax/General/SuccessorCharging.lean) | Target dependency | At most two exceptions can charge the same successor owner |
| [SuccessorPropagation](lean/SmpMax/General/SuccessorPropagation.lean) | Target dependency | Changes forced through the next worse stable partner |
| [SupportCaps](lean/SmpMax/General/SupportCaps.lean) | Target dependency | Formal proof component |
| [WindowEvents](lean/SmpMax/General/WindowEvents.lean) | Target dependency | A finite event cover for a long revelation gap |

## Target dependency order

The following is a topological order of all local imports supporting the final module.

1. `SmpMax.General.Definitions`
2. `SmpMax.General.Separation`
3. `SmpMax.General.Barriers`
4. `SmpMax.General.PartnerIntervals`
5. `SmpMax.General.SuccessorPropagation`
6. `SmpMax.General.BidirectionalPropagation`
7. `SmpMax.General.SupportCaps`
8. `SmpMax.General.PartnerFrame`
9. `SmpMax.General.RevelationGap`
10. `SmpMax.General.GapSides`
11. `SmpMax.General.FiniteRevelation`
12. `SmpMax.General.MatchingRevelation`
13. `SmpMax.General.PermutationCounting`
14. `SmpMax.General.WindowEvents`
15. `SmpMax.General.FiniteProbability`
16. `SmpMax.General.GapTail`
17. `SmpMax.General.LogTail`
18. `SmpMax.General.LogCutoff`
19. `SmpMax.General.PermutationRevelation`
20. `SmpMax.General.ExtendedRevelation`
21. `SmpMax.General.LongPaddedOwners`
22. `SmpMax.General.RelativeOrderProbability`
23. `SmpMax.General.FiniteAverageAlgebra`
24. `SmpMax.General.LongGapEvents`
25. `SmpMax.General.LogEnclosure`
26. `SmpMax.General.RefinedLogBound`
27. `SmpMax.General.ShortSideSaving`
28. `SmpMax.General.RefinedLogCertificate`
29. `SmpMax.General.StructuralLogCertificate`
30. `SmpMax.General.BidirectionalLogCertificate`
31. `SmpMax.General.LongerLogCertificate`
32. `SmpMax.General.LongEventRows`
33. `SmpMax.General.BidirectionalGapSaving`
34. `SmpMax.General.LongDirectionalSaving`
35. `SmpMax.General.LongGapGeometry`
36. `SmpMax.General.LongPaddedSupport`
37. `SmpMax.General.SuccessorCharging`
38. `SmpMax.General.LongMatchingDirectionalSaving`
39. `SmpMax.General.JointGapSaving`
40. `SmpMax.General.JointLogCertificate`
41. `SmpMax.General.JointDirectionalSaving`
42. `SmpMax.General.JointGapGeometry`
43. `SmpMax.General.JointCharging`
44. `SmpMax.General.JointMatchingSaving`
45. `SmpMax.General.JointEntropyUpperBound`
